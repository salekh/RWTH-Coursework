function h = histogram( img )
%HISTOGRAM computes histogram of img
%   assume all pixel values fall inside [0,255]

h = zeros(1,256);

for v = reshape(img,1,size(img,1)*size(img,2))
    h(v+1)=h(v+1)+1;
end

end
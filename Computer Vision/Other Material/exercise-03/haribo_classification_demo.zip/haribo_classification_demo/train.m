function [REF] = train( cam, figures )

se1 = strel('disk',2);
se2 = strel('square',2);

snap = getsnapshot(cam);
figure(figures(1)); imshow(snap); title('input image');

% for more real-time feelings in data acqusition see:
% start, stop, peekdata, getdata
% Doc: Image Acquisition Toolbox -> Working with Acquired Image Data -> Bringing Image Data into the MATLAB Workspace

t = thresh_otsu(double(snap));
if sum(sum(t==1))>sum(sum(t==0)) % main color = background color is white -> invert because "light" objects (1) are labeled
    t = 1-t;
end
figure(figures(2)); imshow(t); title('thresholded image');

tmorph = imdilate(imopen(imerode(t,se1),se2),se1);
figure(figures(3)); imshow(tmorph); title('morphed image');

[label, ids] = object_label(tmorph);
figure(figures(4)); imagesc(label); axis equal; axis off; title('labeled regions');

REF = [];
while(1)
    fprintf('Please click into a labeled region you want to name. (Click inside the figure but outside the image to exit)\n');
    pos = ginput(1);
    pos = round(pos);
    
    if pos(1)<1 || pos(1)>size(snap,2) || pos(2)<1 || pos(2)>size(snap,1)
        fprintf('Exiting.\n');
        break;
    else
        id = label(pos(2),pos(1));
        [X Y]=find(label==id); v=features(X,Y);
        name = input('Please type the name of the object: ','s');
        REF{numel(REF)+1}={v,name};
    end
    
end

end

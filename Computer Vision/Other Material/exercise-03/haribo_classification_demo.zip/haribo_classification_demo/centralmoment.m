function [ mu ] = centralmoment( X, Y, j, k, mx, my )

mu=sum( ((X-mx).^j).*((Y-my).^k) );
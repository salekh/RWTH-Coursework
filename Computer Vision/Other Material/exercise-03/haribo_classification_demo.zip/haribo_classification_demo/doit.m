% authors: Esther Horbert, Pascal Steingrube, Johannes Laudenberg
% contact: pascal.steingrube@rwth-aachen.de

function [ ] = doit( )
% the file REF.mat contains the parameters to recognize different sweets 
% contained in Haribo Colorado (licorice, bat, frog, raspberry, gummibear).
% You can train you own classifier by specifying a different name for the 
% reference data file. If this file does not exist the training function 
% is called and the file with your annotations saved.

close all;clc;

FRAMES=100;

ref_file = 'REF.mat'; % SPECIFY NAME OF TRAINING DATA HERE
% if this file does not exist yet, the training routine is entered and the file saved afterwards


% -------------------------------------------------------------------------
cam = webcam; 
onCleanup(@()stop(cam)); % this will stop the cam at the end even if the program crashes

f1=figure;
set(f1, 'Position', [11     452   484   326]);
f2=figure;
set(f2, 'Position', [511   452   484   326]);
f3=figure;
set(f3, 'Position', [1011  452   484   326]);
f4=figure;
set(f4, 'Position', [11     40    484   326]);
f5=figure;
set(f5, 'Position', [511   40    484   326]);

if size(dir(ref_file),1)~=0 % file exists
    f = load(ref_file);
    REF = f.REF;
    for i=1:FRAMES
        [ snap, t, label, ids ] = perform( REF, cam, [f1 f2 f3 f4 f5] );
    end
else
    disp('Training');
    REF = train(cam, [f1 f2 f3 f4 f5]);
    if size(REF,1)>0
        save REF;
    end
end

end

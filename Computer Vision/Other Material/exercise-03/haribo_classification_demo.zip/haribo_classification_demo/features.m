function [ v ] = features( X,Y )
%invariant moments

mx=mean(X);
my=mean(Y);

n20=ncm(X, Y, 2, 0, mx, my);
n02=ncm(X, Y, 0, 2, mx, my);
n11=ncm(X, Y, 1, 1, mx, my);
n12=ncm(X, Y, 1, 2, mx, my);
n21=ncm(X, Y, 2, 1, mx, my);
n30=ncm(X, Y, 3, 0, mx, my);
n03=ncm(X, Y, 0, 3, mx, my);

v(1)=n20 + n02;
v(2)=(n20 - n02)^2 + 4*n11^2;
v(3)=(n30 - 3*n12)^2 + (3*n21 - n03)^2;
v(4)=(n30 - n12)^2 + (n21 + n03)^2;

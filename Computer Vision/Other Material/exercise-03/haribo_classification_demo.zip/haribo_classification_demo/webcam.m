function [cam ] = webcam
% see "Image Acquisition Toolbox"
% useful command: 
% % >> imaqtool
% % look up your cam settings in a gui
% % (can generate a m-file which sets up the cam)

% Device Properties.
adaptorName = 'linuxvideo';
% vidFormat = 'YUYV_640x480';
vidFormat = 'YUYV_320x240';

vidObj1= videoinput(adaptorName, 1, vidFormat);
set(vidObj1, 'ReturnedColorSpace', 'grayscale');
set(vidObj1, 'FramesPerTrigger', 1);

triggerconfig(vidObj1, 'manual');
start(vidObj1);

getsnapshot(vidObj1); % first captured frame is often corrupted

cam = vidObj1 ;

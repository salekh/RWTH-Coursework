function [ snap, t, label, ids ] = perform( REF, cam, figures )
% [ snap, t, label, ids ] = perform( colormap_labels, REF, cam )
% colormap_labels: to color the labels (something like: rand(256,3))
% REF: list of reference vectors to recognize the connected areas as specified objects
% REF{i} = {featurevector,'textlabel'}
% % e.g.: REF{1} = {[0.201518829584460,0.0147257046966005,4.82258225549523e-06,1.79800436668469e-06;], 'LakritzStange'};
% %       REF{2} = {[0.168791281442670,0.00163750395112310,4.48589027978555e-09,4.56915977991604e-08], 'Cocos';};
% %       REF{3} = {[0.1637,0.0017,0,0],'M&M';}
% %       REF{4} = {[0.1648,0.0010,0,0],'Zuckerhuegel';}
% % remark: use '{ }'! (untyped lists)
%
% authors: Esther Horbert, Pascal Steingrube, Johannes Laudenberg

%cam=webcam;

if nargin<3
    figures = [figure() figure() figure() figure() figure()];
end

se1 = strel('disk',2);
se2 = strel('square',2);

% get some single snapshot (simple but init overhead).
% snap = getsnapshot(cam);
snap = getsnapshot(cam);
figure(figures(1)); imshow(snap); title('input image');

% for more real-time feelings in data acqusition see:
% start, stop, peekdata, getdata
% Doc: Image Acquisition Toolbox -> Working with Acquired Image Data -> Bringing Image Data into the MATLAB Workspace

t = thresh_otsu(double(snap));
if sum(sum(t==1))>sum(sum(t==0)) % main color = background color is white -> invert because "light" objects (1) are labeled
    t = 1-t;
end
figure(figures(2)); imshow(t); title('thresholded image');

tmorph = imdilate(imopen(imerode(t,se1),se2),se1);
figure(figures(3)); imshow(tmorph); title('morphed image');

[label, ids] = object_label(tmorph);
figure(figures(4)); imagesc(label); axis equal; axis off; title('labeled regions');
figure(figures(5)); imshow((uint8((label~=0)).*snap)); title('labels');
for id = ids
    [X Y]=find(label==id);
    if numel(X)>20
        mx=mean(X);
        my=mean(Y);
        v=features(X,Y);
        [C DIST]=nn(REF,v);
        %c(id)=C; dist(id)=DIST;
        
        text(my,mx,REF{C}{2},'Color','r')
    end
end
    
end

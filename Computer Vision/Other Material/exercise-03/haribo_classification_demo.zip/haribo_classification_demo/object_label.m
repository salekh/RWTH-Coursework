function [ label, ids ] = object_label( img )

    label = bwlabel(img); % give each connected component a label
    ids = unique(label); % find all used labels
    ids = ids(2:end); % get rid of label 0
    ids = ids'; % need line vector
    
end
        
function res=thresh(img,T)

res = img>=T;

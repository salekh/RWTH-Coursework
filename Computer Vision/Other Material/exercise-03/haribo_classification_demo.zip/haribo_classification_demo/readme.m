function [] = readme()
% (1) try 
%  >> cam=webcam; imshow(getsnapshot(cam));
%  to check if the camera is working, otherwise see in the file ('webcam.m') for more details.
%
% (2) just
%  >> doit
%  
%  or see
%  >> help perform
%  for more details.
%
% by Pascal Steingrube
% contact: pascal.steingrube@rwth-aachen.de

end

function res = thresh_otsu(img)

h = histogram(img);
ch = cumsum(h);

minT = floor(max(2,min(min(img))));
maxT = ceil(max(max(img)));
N = ch(end);
sig_btw = zeros(1,maxT);

for T = minT:maxT,
    % get the number pixels in each cluster
    n1 = ch(T-1);
    n2 = N-n1;
    
    % get the cluster means
    my1 = weighted_mean(h,1,T-1);
    my2 = weighted_mean(h,T,maxT);
    
    %compute sigma_between
    sig_btw(T) = n1*n2*(my1-my2)^2;
end;

[Smax,Tmax] = max(sig_btw);
res = thresh(img,Tmax(1));

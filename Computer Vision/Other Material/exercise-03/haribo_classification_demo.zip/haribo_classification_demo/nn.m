function [ id, DIST ] = nn( REF, obs )

for id = 1:numel(REF)
    dist(id)=sum((REF{id}{1}-obs).^2);
end

[DIST id]=min(dist);
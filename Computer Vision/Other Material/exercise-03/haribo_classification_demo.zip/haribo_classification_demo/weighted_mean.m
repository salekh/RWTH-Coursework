function [ wm ] = weighted_mean( h, rmin, rmax )
%WEIGHTED_MEAN weighted mean of "h" in range "rmin:rmax"

%default values
if nargin<2
    rmin=1;
end
if nargin<3
    rmax=numel(h);
end

range=rmin:rmax;
wm=sum((h(range).*range))/sum(h(range));
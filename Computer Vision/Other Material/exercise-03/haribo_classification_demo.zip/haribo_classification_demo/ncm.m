function [ n ] = ncm( X, Y, p, q, mx, my )

gamma=((p+q)/2)+1;
n=centralmoment(X,Y,p,q,mx,my)/(numel(X)^gamma);
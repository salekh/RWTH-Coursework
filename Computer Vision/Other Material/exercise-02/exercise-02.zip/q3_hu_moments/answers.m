function a = answers()
	a.hu_moments = 'Textual answer to hu moments.';
end

function imgEdge = getedges2(img, sigma, theta)
% insert your code here
end

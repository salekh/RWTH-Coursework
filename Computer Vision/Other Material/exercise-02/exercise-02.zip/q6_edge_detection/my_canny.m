function edge_image = my_canny(img, sigma, theta_low, theta_high)
% insert your code here
end

function imgEdge = getedges(img, sigma, theta)
% insert your code here
end

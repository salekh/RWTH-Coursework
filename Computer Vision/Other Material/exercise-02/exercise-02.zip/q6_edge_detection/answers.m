function a = answers()
	a.difficulties_sigma_theta = 'What difficulties do you observe when choosing sigma and theta?';
	a.nms = 'Describe your results.';
	a.hysteresis = 'What do you observe?';
end

function gaussian = gauss(x, sigma)
% insert your code here
end

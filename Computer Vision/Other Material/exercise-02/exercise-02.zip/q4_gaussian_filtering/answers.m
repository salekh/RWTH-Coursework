function a = answers()
	a.own_implementation = 'Was your own implementation correct?';
end

function outimg = gaussianfilter(inimg, sigma)
% insert your code here
end

function [imgDx, imgDy] = gaussderiv(img, sigma)
% insert your code here
end

function [imgDxx, imgDxy, imgDyy] = gaussderiv2(img, sigma)
% insert your code here
end

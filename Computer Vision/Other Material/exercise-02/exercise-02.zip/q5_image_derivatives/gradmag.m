function [imgMag, imgDir]=gradmag(img, sigma)
% insert your code here
end

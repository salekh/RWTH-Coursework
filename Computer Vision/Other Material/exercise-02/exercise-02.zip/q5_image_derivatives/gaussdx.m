function derivative = gaussdx(x, sigma)
% insert your code here
end

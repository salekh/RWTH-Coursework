function imgLap=laplace(img, sigma)
% insert your code here
end

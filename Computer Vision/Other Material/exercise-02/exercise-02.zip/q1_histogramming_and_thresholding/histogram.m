function hist = histogram(img)
% insert your code here
end

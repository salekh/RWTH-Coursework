function wm = weighted_mean(vec, rmin, rmax)
% insert your code here
end

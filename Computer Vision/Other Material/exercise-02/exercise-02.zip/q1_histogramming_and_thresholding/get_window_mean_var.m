function [m, v] = get_window_mean_var(img, x, y, r)
% insert your code here
end

function res = thresh_niblack(img, r, k)
% insert your code here
end

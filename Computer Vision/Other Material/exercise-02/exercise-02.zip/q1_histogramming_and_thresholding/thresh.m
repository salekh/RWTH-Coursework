function res = thresh(img, threshold)
% insert your code here
end

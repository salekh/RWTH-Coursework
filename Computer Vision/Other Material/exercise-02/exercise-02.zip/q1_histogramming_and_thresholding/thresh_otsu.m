function res = thresh_otsu(img)
% insert your code here
end

function p = parameters()
	p.images = 'a'; %alternative b
	p.windowsize.lucas_kanade = 4;
	p.windowsize.iterative_lucas_kanade = 4;
	p.windowsize.ctf_lucas_kanade = 4;
	p.n_iterations = 10;
end

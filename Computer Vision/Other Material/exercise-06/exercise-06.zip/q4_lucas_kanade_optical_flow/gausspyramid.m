function pyramid = gausspyramid(im)


	% insert your code here

end

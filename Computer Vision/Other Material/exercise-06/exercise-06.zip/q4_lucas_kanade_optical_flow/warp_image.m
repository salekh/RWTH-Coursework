function im_w = warp_image(im, u, v)

	% Input:

	%   im:  the input image

	%   u,v: the optical flow

	% Output:

	%   im_w: the warped image


	% insert your code here

end

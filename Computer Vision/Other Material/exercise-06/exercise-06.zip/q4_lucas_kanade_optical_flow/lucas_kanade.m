function [u, v] = lucas_kanade(im1, im2, window_size)

	% Input:

	%   im1, im2:    The pair of images that the optical flow is computed on

	%   window_size: The size of the optical flow window

	% Output:

	%   u, v:        The optical flow windows in u and v direction


	% insert your code here

end

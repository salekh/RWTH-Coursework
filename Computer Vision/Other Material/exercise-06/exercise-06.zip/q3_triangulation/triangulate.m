function X = triangulate(P1, x1, P2, x2)


	% insert your code here

end

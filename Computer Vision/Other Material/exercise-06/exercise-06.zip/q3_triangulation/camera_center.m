function center = camera_center(P)


	% insert your code here

end

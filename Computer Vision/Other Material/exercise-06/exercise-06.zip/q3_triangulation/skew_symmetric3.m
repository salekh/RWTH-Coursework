function skew_sym = skew_symmetric3(v)


	% insert your code here

end

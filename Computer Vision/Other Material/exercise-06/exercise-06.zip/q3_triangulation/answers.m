function a = answers()
	a.metric = 'Why is it not possible to obtain a metric reconstruction in this case without calibration?';
	a.result = 'How does the result look?';
end

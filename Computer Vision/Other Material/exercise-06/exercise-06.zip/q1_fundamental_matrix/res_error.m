function error=res_error(F, x1, x2)


	% insert your code here

end

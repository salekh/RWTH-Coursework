function [F e1 e2] = fundmatrix(x1, x2)

	% Input:

	% x1,x2 : 3xN arrays of N homogenous points in 2D

	% Output:

	% F : The 3x3 fundamental matrix such that x2'*F*x1 = 0

	% e1 : The epipole in image 1 such that F*e1 = 0

	% e2 : The epipole in image 2 such that F'*e2 = 0


	% insert your code here

end

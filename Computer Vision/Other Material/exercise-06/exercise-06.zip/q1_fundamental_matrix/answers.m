function a = answers()
	a.estimation = 'What do you observe? What happens when your correspondence set contains outliers?';
	a.estimation_error = 'How big are the residual errors for the normalized and the unnormalized Eight-point algorithms? What is the effect of noise, outliers and the number of correspondences?'
end

function [x1, x2] = inputcorresp(img1, img2, N)


	% insert your code here

end

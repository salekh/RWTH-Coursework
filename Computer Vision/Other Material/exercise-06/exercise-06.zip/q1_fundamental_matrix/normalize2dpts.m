function [newpts T] = normalize2dpts(pts)

	% Input:

	% pts :   3xN array of N homogenous points in 2D

	% Output:

	% newpts: 3xN matrix of transformed points

	% T : the 3x3 transformation matrix, newpts = T*pts


	% insert your code here

end

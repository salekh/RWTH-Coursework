function [x1 x2] = get_inliers(F, x1, x2, eps)

    % normalize points


	% insert your code here

end

function [F e1 e2 xi1 xi2] = ransac_fundmatrix(x1, x2, eps, k)

% Input:

%   x1,x2 : 3xN arrays of N homogenous points in 2D

%   eps   : inlier threshold

%   k     : number of iterations

% Output:

%   F       : The 3x3 fundamental matrix such that x2'*F*x1 = 0

%   e1      : The epipole in image 1 such that F*e1  = 0

%   e2      : The epipole in image 2 such that F'*e2 = 0

%   xi1,xi2 : 3xNi arrays of Ni homogenous inlier points in 2D


	% insert your code here

end

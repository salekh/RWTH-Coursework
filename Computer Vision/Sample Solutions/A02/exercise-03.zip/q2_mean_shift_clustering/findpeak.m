function peak = findpeak(data, idx, r) 

	p = size(data, 2);
	last_shift = Inf;

	r2 = r^2;                                   % precomputation

	current_point = data(:, idx);

	while last_shift > 0.1
		% Find points inside the spherical window
		indices = sum( (data - repmat(current_point, 1, p)).^2, 1) < r2;
 		 		
		% Shift the current point to their center
		A = data(:, indices);
		old = current_point;
		current_point = mean(A, 2);
		last_shift = sqrt(sum((old - current_point).^2));
	end
 		 		
	peak = current_point;

end

function a = answers()
	a.radius = 'Which radius gives good results? How did you choose it?';
	a.optimized = 'How much faster is the optimized version? Does it change the result? If yes, is the result worse?';
end

function [peak,cpts] = findpeak_opt(data, idx, r) 

	p = size(data, 2);

	t = 0.1;                                    % threshold
	last_shift = Inf;                           % keep track of last shift

	c = 4;                                      % use 1/c of the radius
	cpts = zeros(1, p);                         % points on the path

	r2 = r^2;                                   % precomputation
	rc2 = (r/c)^2;                              % precomputation

	current_point = data(:, idx);

	while last_shift >= t % shift was above threshold
		% collect all points with distance <=r
		distances2 = sum((data - repmat(current_point, 1, size(data, 2))).^2, 1); % distance to current_point

		% compute mean and shift window
		new_point = mean(data(:, distances2<=r2), 2);

		% store search path
		cpts(distances2 < rc2) = 1;

		last_shift = norm(current_point - new_point);
		current_point = new_point;
	end

	peak = current_point;
	cpts = logical(cpts);

end

function analyse_featurechannels_luv_pos (  )

	img = imread('terrain.png');
%	img = imread('terrain_small.png');

	width = size(img,2);
	height = size(img,1);

	% Reshape img to get 3xM matrix (where M is img_width * img_height)
	pts = zeros(3, width * height);
	pos = zeros(2, width * height);
	for j = 1:width
		for i = 1:height
			pts(:, (j-1)*height+i) = img(i, j, :);
			pos(:, (j-1)*height+i) = [i; j];
		end
	end

%	% Keep RGB
%	chan = {'Color (R)','Color (G)','Color (B)','Position (x)','Position (y)'};

	% Convert the vectorized image to LUV
	pts = rgb2luv(pts./255);
	chan = {'Color (L)','Color (u)','Color (v)','Position (x)','Position (y)'};

	% Attach the points' positions
	pts = [pts; pos];

	% Histograms of the feature channels
	figure ();

	for i = 1:5
		subplot(1, 5, i);
		histogram( pts(i,:), 20 );
		title(chan{i});
		drawnow;
	end

end



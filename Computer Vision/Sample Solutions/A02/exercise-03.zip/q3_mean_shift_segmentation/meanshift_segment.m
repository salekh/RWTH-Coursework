function seg_img = meanshift_segment(img, r)

	width = size(img, 2);
	height = size(img, 1);

	% reshape img to get 3xM matrix (where M is img_width * img_height)
	pts = zeros(3, width * height );
	for j = 1:width
		for i=1:height
			pts(:, (j-1) * height + i) = img(i, j, :);
		end
	end
	% this can also be done with the function reshape 
	% (be careful in which order matlab traverses the elements of the matrix!)
	% pts = double(reshape(img, [width * height, 3])');

	% Find color modes using mean shift
	[labels, peaks ] = meanshift_opt(pts, r);

	% Reshape the result back to an image
	seg_img = double(zeros(height, width, 3));
	for j = 1:width
		for i=1:height
			seg_img(i, j, :) = peaks(:, labels((j-1) * height + i) );
		end
	end
 	 	  
	seg_img = uint8(seg_img);

end

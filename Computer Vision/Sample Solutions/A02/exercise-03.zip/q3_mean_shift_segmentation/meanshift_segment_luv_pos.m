function seg_img = meanshift_segment_luv_pos(img, r)

	width = size(img,2);
	height = size(img,1);

	% reshape img to get 3xM matrix (where M is img_width * img_height)
	pts = zeros(3, width * height);
	pos = zeros(2, width * height);
	for j = 1:width
		for i = 1:height
			pts(:, (j-1)*height+i) = img(i, j, :);
			pos(:, (j-1)*height+i) = [i; j];
		end
	end

	% Convert the vectorized image to LUV
	pts = rgb2luv(pts./255);

	% Attach the points' positions
	pts = [pts; pos];

	% Find color modes using mean shift
	[labels, peaks] = meanshift_opt(pts, r);

	% Remove the peaks' positions
	peaks = peaks(1: 3, :);

	% Convert the peak colors back to RGB
	peaks = luv2rgb(peaks);

	% Reshape the result back to an image
	seg_img = double(zeros(height, width, 3));
	for j = 1:width
		for i = 1:height
			seg_img(i, j, :) = peaks(:, labels((j-1) * height + i) );
		end
	end

	seg_img = uint8(seg_img.*255);

end

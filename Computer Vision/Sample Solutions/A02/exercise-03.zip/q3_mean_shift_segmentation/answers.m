function a = answers()
	a.meanshift_segmentation = 'What effect does varying r and the feature vector seem to have on the resulting segmentations? What effect does adding position information have on the resulting segmentations? What are the advantages and disadvantages of using each type of feature vector? Can you suggest any extensions that might avoid many of the situations where single regions are over-segmented into multiple regions?';
end

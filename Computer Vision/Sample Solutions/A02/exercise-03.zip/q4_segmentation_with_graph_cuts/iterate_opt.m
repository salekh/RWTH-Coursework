function labeling = iterate_opt(img, foreground_mask, n_bins, unary_weight, pairwise_pot, n_iter)

	[h,w,~] = size(img);

	for iter = 1:n_iter
		%iter

		%histogram
		fg_histogram = calculate_histogram(img,foreground_mask, n_bins);
		bg_histogram = calculate_histogram(img,1-foreground_mask, n_bins);

		%create foreground map
		foreground_probability = foreground_pmap(img, fg_histogram, bg_histogram);
		foreground_map = foreground_probability > 0.5;

		%unary and pairwise potentials
		unary_fg = unary_potentials(foreground_probability, unary_weight);
		unary_bg = unary_potentials(1 - foreground_probability, unary_weight);
		unary = single(...
			 [ reshape(unary_fg, 1, numel(unary_fg));...
				reshape(unary_bg, 1, numel(unary_bg))] ...
		);

		[labels, ~, ~] = ...
			 GCMex( ...
				  double(reshape(foreground_map,1,numel(foreground_map))),...
				  unary, ...
				  pairwise_pot, ...
				  single(cost_mat(2)), ...
				  0);

		final_labeling = reshape(labels,h,w);
		foreground_mask = 1 - final_labeling;
	end

	labeling = final_labeling;
end

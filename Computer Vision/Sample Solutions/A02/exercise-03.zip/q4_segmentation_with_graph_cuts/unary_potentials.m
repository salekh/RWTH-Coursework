function potentials = unary_potentials(probability, unary_weight)
	potentials = -log( probability ) * unary_weight;
end

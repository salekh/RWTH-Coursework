function cost = cost_mat(n)
	cost = 1 - eye(n);
end

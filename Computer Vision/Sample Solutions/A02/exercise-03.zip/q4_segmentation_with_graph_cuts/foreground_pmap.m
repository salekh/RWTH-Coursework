function foreground_map = foreground_pmap(img, fg_histogram, bg_histogram)

	n_bins = size(fg_histogram,2);
	h = size(img,1);
	w = size(img,2);
	foreground_map = zeros(h,w);
    
	for y = 1:h
		for x = 1:w
			bins = min(n_bins, round( img(y,x,:)/256 * n_bins ) + 1);
			fg_score = fg_histogram(bins(1), bins(2), bins(3));
			bg_score = bg_histogram(bins(1), bins(2), bins(3));
 		  	
			foreground_map(y,x) = fg_score/(fg_score+bg_score);
		end
	end

end

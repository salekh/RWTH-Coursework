function idx = coord_transform(height, x, y)
	idx = ((x-1) * height) + y;
end

function score = pairwise_potential_prefactor(img,x1,y1,x2,y2, pairwise_weight)

	img = double(img);

	% simple version:
	score = pairwise_weight;

%	% Potts model, bonus question:
	score = pairwise_weight * exp( -1 * norm(squeeze(img(y1,x1,:) - img(y2,x2,:))) ^ 2 );

end

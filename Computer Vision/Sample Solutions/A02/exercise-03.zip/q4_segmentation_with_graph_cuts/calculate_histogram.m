function histogram = calculate_histogram(img, mask, n_bins)

	initial_value = 0.001;
	bins = min(n_bins, round( img/256 * n_bins ) + 1);
	histogram = initial_value * ones(n_bins, n_bins, n_bins);
	[h,w,~] = size(img);
		 			
	for y = 1:h
		for x = 1:w
			if mask(y,x) ~= 0
				histogram( bins(y,x,1), bins(y,x,2), bins(y,x,3) ) = ...
					histogram( bins(y,x,1), bins(y,x,2), bins(y,x,3) ) + 1;
			end
		end
	end

	%normalize
	histogram = histogram/sum(histogram(:));

end

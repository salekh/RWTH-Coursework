function houghSpace=houghtransform(imgEdge,nBinsRho,nBinsTheta)

	acc     = zeros(nBinsRho,nBinsTheta);   % Accumulator
	D       = norm(size(imgEdge));          % Image diagonal
 	 		 
	% Hough-Transformation
	for x = 1:size(imgEdge,2)
		for y = 1:size(imgEdge,1)
			if imgEdge(y,x) == 1
				% for an edge pixel, do ...
				for n = 1:nBinsTheta
					theta = -pi/2 + pi * (n-1)/(nBinsTheta-1); % bin index -> theta
					rho = x*cos(theta) + y*sin(theta);         % theta -> rho
					m = round((nBinsRho-1)*(rho+D)/(2*D))+1;   % rho -> bin index
					acc(m,n) = acc(m,n) + 1;                   % vote!
				end
			end
		end
	end

	houghSpace = acc;
 	 		 
end

function [vRho vTheta] = findhoughpeaks(houghSpace, thresh)

	houghMaxima = nonmaxsup2d(houghSpace);
	houghMaxima(houghMaxima < thresh) = 0;
	[vRho vTheta] = find(houghMaxima);
   		 
end

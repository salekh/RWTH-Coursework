function a = answers()
	a.all_lines = 'Do you find all the lines?';
	a.houghcircle = 'Explain your approach.';
	a.classification = 'Explain your approach.';
end

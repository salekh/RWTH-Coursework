function a = answers()
	a.combination = 'Which combination works best?';
end

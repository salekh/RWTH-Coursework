function [] = apply()
close all;clc;

a = answers();

disp('Question: Hu Moments');

disp(a.hu_moments);

end

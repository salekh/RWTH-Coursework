function a = answers()
	a.impulse_image = 'Describe your results.';
	a.gradmag = 'Describe your results.';
	a.laplace = 'Describe your results.';
end

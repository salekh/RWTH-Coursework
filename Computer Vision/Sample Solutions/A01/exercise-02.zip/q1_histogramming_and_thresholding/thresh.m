function res = thresh(img, threshold)

	res = (img >= threshold);
  	 	 
end

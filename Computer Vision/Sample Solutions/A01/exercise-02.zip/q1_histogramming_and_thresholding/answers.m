function a = answers()
	a.grayvalue_histogram = 'Describe what you see.';
	a.cumulative_histogram = 'Describe what you see.';
	a.threshold = 'Descibe how you chose the threshold.';
	a.niblack = 'What do you observe?';
end

function [u, v] = lucas_kanade(im1, im2, window_size)
	% Input:
	%   im1, im2:    The pair of images that the optical flow is computed on
	%   window_size: The size of the optical flow window
	% Output:
	%   u, v:        The optical flow windows in u and v direction

	[m, n] = size(im1);
	halfWindow = floor(window_size/2);

	u = zeros(size(im1));
	v = zeros(size(im2));

	% Compute gradients in x-, y- and t-directions
	[Ix, Iy] = gaussderiv(im1, 1);
	It = gaussianfilter(im2, 1) - gaussianfilter(im1, 1);

	for i = 1:m
		for j = 1:n
			% Extract windows from the gradient images images
			ls = max(i - halfWindow, 1):min(i + halfWindow, m);
			cs = max(j - halfWindow, 1):min(j + halfWindow, n);

			A = [reshape(Ix(ls, cs), [], 1), reshape(Iy(ls, cs), [], 1)];
			b = -reshape(It(ls, cs), [], 1);

			% Solve the linear system
			warning off all; %suppress warning concerning rank deficiency
			d = A\b;
			warning on all;

			u(i,j) = d(1);
			v(i,j) = d(2);
		end
	end

	% Set the pixels where the flow equation was unsolvable to have 0 flow
	u(isnan(u)) = 0;
	v(isnan(v)) = 0;
end

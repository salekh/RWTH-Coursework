function [u, v, im1, im2] = ctf_lucas_kanade(im1, im2, window_size)
	% Input:
	%   im1, im2:    The pair of images that the optical flow is computed on
	%   window_size: The size of the optical flow window
	% Output:
	%   u, v:        The optical flow windows in u and v direction

	w_pad = 2^ceil(log2(size(im1, 2)));
	h_pad = 2^ceil(log2(size(im1, 1)));
	im1(h_pad, w_pad) = 0;
	im2(h_pad, w_pad) = 0;

	py1 = gausspyramid(im1);
	py2 = gausspyramid(im2);
	n_layers = size(py1, 2);

	% Ensure the 1st layer is big enough for our sliding window
	n_layers = n_layers - floor(log2(3 * window_size));

	u_total = zeros(size(py1{n_layers}));
	v_total = zeros(size(py1{n_layers}));

	fh = figure('Position', [100,200,700,400], 'Name', 'Question: Lucas-Kanade');

	for layer = n_layers:-1:1
		% Compute lucas kanade for the current layer
		[u, v] = lucas_kanade(py1{layer}, py2{layer}, window_size);

		% Accumulate to the flow from previous iterations.
		% Don't forget to scale up the flow values!
		u_total = u_total + u;
		v_total = v_total + v;

		% Display the flow field
		ud = imresize(u_total, size(im1));
		vd = imresize(v_total, size(im1));
		image(flowToColor(ud, vd));
		axis equal;
		axis off;

		%im1w = warp_image(im1, ud, vd);
		%imagesc(im1w); colormap gray;
		fprintf('Layer %d\n', layer);
		pause(.2);

		% Apply the flow field to the next layer
		if layer > 1
			% Scale up the flow field
			u_total = imresize(u_total, 2)*2;
			v_total = imresize(v_total, 2)*2;

			py1{layer - 1} = warp_image(py1{layer - 1}, u_total, v_total);
		end
	end

	u = u_total;
	v = v_total;

	pause(.5);
	close(fh);
end

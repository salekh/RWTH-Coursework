function a = answers()
	a = 0;
end

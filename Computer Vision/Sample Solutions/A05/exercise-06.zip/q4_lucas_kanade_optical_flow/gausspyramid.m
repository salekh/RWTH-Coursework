function pyramid = gausspyramid(im)
	n_levels = ceil(log2(min(size(im))));
	pyramid = cell(n_levels);
	pyramid{1} = im;
	for level = 2:n_levels
		pyramid{level} = imresize(pyramid{level - 1}, 0.5);
	end
end

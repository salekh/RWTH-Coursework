function im_w = warp_image(im, u, v)
	% Input:
	%   im:  the input image
	%   u,v: the optical flow
	% Output:
	%   im_w: the warped image
	[gridX, gridY] = meshgrid(1:size(im, 2), 1:size(im, 1));
	im_w = interp2(gridX, gridY, im, gridX - u , gridY - v);
end

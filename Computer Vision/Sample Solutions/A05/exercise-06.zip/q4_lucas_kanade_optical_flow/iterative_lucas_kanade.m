function [u, v] = iterative_lucas_kanade(im1, im2, window_size, n_iters)
	% Input:
	%   im1, im2:    The pair of images that the optical flow is computed on
	%   window_size: The size of the optical flow window
	% Output:
	%   u, v:        The optical flow windows in u and v direction

	[u, v] = lucas_kanade(im1, im2, window_size);

	fh1 = figure('Position', [200, 200, 600, 400], 'Name', 'Question: Lucas-Kanade');
	fh2 = figure('Position', [800, 200, 600, 400], 'Name', 'Question: Lucas-Kanade');

	u_total = u;
	v_total = v;

	for i=1:n_iters
		im1_w = warp_image(im1, u_total, v_total);
		[u, v] = lucas_kanade(im1_w, im2, window_size);
		u_total = u_total + u;
		v_total = v_total + v;

		figure(fh1);
		image(flowToColor(u_total, v_total));
		axis equal;
		axis off;
		title(sprintf('Iterative Lucas Kanade - Intermediate result - step %d/%d', i, n_iters));

		figure(fh2);
		imagesc(warp_image(im1, u_total, v_total));
		colormap gray;
		axis equal;
		axis off;
		title(sprintf('Iterative Lucas Kanade - Intermediate result - step %d/%d', i, n_iters));
		drawnow;
	end

	u = u_total;
	v = v_total;

	pause(.5);
	close(fh1);
	close(fh2);
end

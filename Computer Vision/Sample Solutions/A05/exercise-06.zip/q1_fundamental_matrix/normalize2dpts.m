function [newpts T] = normalize2dpts(pts)
	% Input:
	% pts :   3xN array of N homogenous points in 2D
	% Output:
	% newpts: 3xN matrix of transformed points
	% T : the 3x3 transformation matrix, newpts = T*pts

	% Ensure homogeneous coords have scale of 1
	pts(1, :) = pts(1, :)./pts(3, :);
	pts(2, :) = pts(2, :)./pts(3, :);
	pts(3, :) = 1;

	% Shift origin to centroid
	c = mean(pts, 2);
	T1 = [1   0   -c(1)
	      0   1   -c(2)
	      0   0    1   ];

	cpts = T1 * pts;

	% Normalize the distances
	dist = sqrt(cpts(1, :).^2 + cpts(2, :).^2);
	meandist = mean(dist(:));

	scale = sqrt(2)/meandist;
   
	% Construct the transformation matrix
	T2 = [scale   0    0
	      0     scale  0
	      0       0    1   ];
	T = T2 * T1;

	newpts = T * pts;
end

function [F e1 e2] = fundmatrix(x1, x2)
	% Input:
	% x1,x2 : 3xN arrays of N homogenous points in 2D
	% Output:
	% F : The 3x3 fundamental matrix such that x2'*F*x1 = 0
	% e1 : The epipole in image 1 such that F*e1 = 0
	% e2 : The epipole in image 2 such that F'*e2 = 0

	% hint: test this function by checking if
	% x2(:,1)'*F*x1(:,1) is (close to) 0

	% Build the constraint matrix
	npts = size(x1,2);

	u1 = x1(1, :)';
	v1 = x1(2, :)';
	u2 = x2(1, :)';
	v2 = x2(2, :)';

	A = [(u1.*u2) (u1.*v2) u1 (v1.*u2) (v1.*v2) v1 u2 v2 ones(npts,1)];

	% Solve Ax=0 using SVD
	[U, D, V] = svd(A, 0); % Use the economy decomposition

	% Extract fundamental matrix from the column of V corresponding to
	% smallest singular value.
	F = reshape(V(:, 9), 3, 3);

	% Enforce constraint that fundamental matrix has rank 2 by performing
	% a svd and then reconstructing with the two largest singular values.
	[U, D, V] = svd(F, 0);
	D(3, 3) = 0;
	F = U * D * V';

	% Compute epipoles
	[U, D, V] = svd(F, 0);
	e1 = V(:, 3)./V(3, 3);
	e2 = U(:, 3)./U(3, 3);
end

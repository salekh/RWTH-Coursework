function [F e1 e2] = normfundmatrix(x1, x2)
	% Input:
	% x1,x2 : 3xN arrays of N homogenous points in 2D
	% Output:
	% F : The 3x3 fundamental matrix such that x2'*F*x1 = 0
	% e1 : The epipole in image 1 such that F*e1 = 0
	% e2 : The epipole in image 2 such that F'*e2 = 0

	% Normalize each set of points so that the origin 
	% is at centroid and mean distance from origin is sqrt(2). 
	% normalize2dpts also ensures the homogeneous component is 1.
	[x1, T1] = normalize2dpts(x1);
	[x2, T2] = normalize2dpts(x2);

	% Calculate the fundamental matrix of the normalized points
	[F, e1, e2] = fundmatrix(x1, x2);

	% Undo the transformation
	F = T2' * F * T1;

	% Compute epipoles
	[U,D,V] = svd(F, 0);
	e1 = V(:, 3)./V(3, 3);
	e2 = U(:, 3)./U(3, 3);
end

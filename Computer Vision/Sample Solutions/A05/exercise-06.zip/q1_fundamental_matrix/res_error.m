function error=res_error(F, x1, x2)
    
    % normalize points
    x1 = x1./repmat(x1(3,:),3,1);
    x2 = x2./repmat(x2(3,:),3,1);
    
    % calculate the distance to the projection
    L = (F * x1)';
    % normalize lines
    lengths = sqrt(L(:,1).^2 + L(:,2).^2);
    L = L ./ repmat(lengths ,1, 3);
    
    % length of the projection on the normal ray
    dists = sum((L .* x2'), 2);
    
    error = mean ( dists.^2 );
end

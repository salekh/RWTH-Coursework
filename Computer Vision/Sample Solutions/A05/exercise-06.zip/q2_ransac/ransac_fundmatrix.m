function [F e1 e2 xi1 xi2] = ransac_fundmatrix(x1, x2, eps, k)
% Input:
%   x1,x2 : 3xN arrays of N homogenous points in 2D
%   eps   : inlier threshold
%   k     : number of iterations
% Output:
%   F       : The 3x3 fundamental matrix such that x2'*F*x1 = 0
%   e1      : The epipole in image 1 such that F*e1  = 0
%   e2      : The epipole in image 2 such that F'*e2 = 0
%   xi1,xi2 : 3xNi arrays of Ni homogenous inlier points in 2D
    N = size(x1,2);
    n = 8;
    
    nbr_inliers = n-1; % at least n correspondences needed
    bxi1 = [];
    bxi2 = [];
    
    for i=1:k
        % randomly select seed group of points
        perm = randperm(N);
        x1p = x1(:,perm(1:n));
        x2p = x2(:,perm(1:n));
        
        % compute transformation from seed group
        [Fp e1p e2p] = normfundmatrix(x1p, x2p);
        
        % find inliers to this transformation
        [xi1 xi2] = get_inliers(Fp, x1, x2, eps);
        
        % if number of inliers is sufficiently large, recompute least-squares estimate of transformation on all of the inliers
        % keep the transformation with the largest number of inliers
        if size(xi1,2)>nbr_inliers
            nbr_inliers = size(xi1,2);
            bxi1 = xi1;
            bxi2 = xi2;
        end
        
    end
    
    if isempty(bxi1)
        fprintf('ERROR: RANSAC was not able to find a sufficient number of inliers!\n');
    else
        [F e1 e2] = normfundmatrix(bxi1, bxi2);
        [xi1 xi2] = get_inliers(F, x1, x2, eps);
    end
    
end

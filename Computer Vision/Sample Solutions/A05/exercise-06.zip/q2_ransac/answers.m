function a = answers()
	a.iterations = 'How many RANSAC iterations do we need to perform at least?';
	a.epsilon = 'What do you observe when changing epsilon? Can you think of an explaination?';
	a.solution = 'Does your implementation find a good solution?';
	a.threshold = 'Which effect does changing the threshold have?';
end

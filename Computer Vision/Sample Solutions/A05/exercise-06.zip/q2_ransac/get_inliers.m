function [x1 x2] = get_inliers(F, x1, x2, eps)
    % normalize points
    x1 = x1./repmat(x1(3,:),3,1);
    x2 = x2./repmat(x2(3,:),3,1);
    
    % compute epipolar lines
    L1 = F'*x2;
    L2 = F*x1;
    
    % normalize lines
    L1 = L1./repmat(sqrt(L1(1,:).^2+L1(2,:).^2),3,1);
    L2 = L2./repmat(sqrt(L2(1,:).^2+L2(2,:).^2),3,1);
    
    % compute distances
    dists1 = abs(sum(L1.*x1));
    dists2 = abs(sum(L2.*x2));
    
    inliers = find((dists1<eps) & (dists2<eps));
    x1 = x1(:,inliers);
    x2 = x2(:,inliers);
end

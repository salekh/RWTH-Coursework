function p = parameters()
	p.dataset = 'house'; %alternative: library
end

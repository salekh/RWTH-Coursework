function center = camera_center(P)
	[U, D, V] = svd(P);
	center = V(:, end);
	center = center ./ center(4);
end

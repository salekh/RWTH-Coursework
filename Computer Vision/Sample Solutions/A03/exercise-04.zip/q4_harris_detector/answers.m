function a = answers()
	a.harris_parameters = 'What do you observe?';
	a.harris_scale = 'What happens if you do not use the scale space normalization and why?';
end

function p = parameters()
	p.sigmas = [0.5 1];
	p.threshs = [25 50 100];
end

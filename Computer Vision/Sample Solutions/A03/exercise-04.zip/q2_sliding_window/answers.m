function a = answers()
	a.hoglike_descriptor = 'Describe what you see. Can you spot any striking HOG-cells in the positive and negative example?';
    a.detector = 'How does the result look';
    a.nms = 'Does the result look better? Can you find examples where it fails? Can you imagine a downside of non-maximum-supression?';	
	a.bilinear_interpolation = 'What do you observe?';
end

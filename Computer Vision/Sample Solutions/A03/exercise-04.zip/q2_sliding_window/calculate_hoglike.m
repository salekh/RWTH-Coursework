function hog = calculate_hoglike(img, cellsize, n_bins, sigma, offset_lr, offset_tb, interpolation)
	[image_height, image_width] = size(img);
	
	[mag, dir] = imgradient(img, sigma);
	
	%cut off border
	mag = mag(1 + offset_tb:(image_height - offset_tb), 1 + offset_lr:(image_width - offset_lr));
	dir = dir(1 + offset_tb:(image_height - offset_tb), 1 + offset_lr:(image_width - offset_lr));
	[image_height, image_width] = size(dir);
	  	 	
	n_x = floor(image_width/cellsize);
	n_y = floor(image_height/cellsize);
	hog = zeros(n_y, n_x, n_bins);

	for x=1:image_width
		for y=1:image_height
			
			if interpolation
				[cells_x, cells_y, weights] = get_cell_weights(image_height, image_width, cellsize, x, y);
			else
				[cells_x, cells_y, weights] = get_cell(image_height, image_width, cellsize, x, y);
			end
			
			gradient_direction = pi + dir(y,x);
			gradient_magnitude = mag(y,x);
			modulo = mod(gradient_direction, pi);
			grad_bin = floor(n_bins * modulo / pi) + 1;
	 		 	
			for idx=1:size(cells_x,1)
				x_idx = cells_x(idx);
				y_idx = cells_y(idx);
				weight = weights(idx);

				if interpolation
					hog(y_idx, x_idx, :) =  ...
						hog(y_idx, x_idx, :) + weight * gradient_magnitude .* reshape(trilinear_interpolation(n_bins, gradient_direction), 1, 1, n_bins);
				else
					hog(y_idx, x_idx, grad_bin) =  ...
						hog(y_idx, x_idx, grad_bin) + weight * gradient_magnitude;
				end
			end
		end
	end
	
	%normalization
	for x=1:n_x
		for y=1:n_y
			hog(y,x,:) = hog(y,x,:)/sum(hog(y,x,:));
		end
	end
	  	 	
end

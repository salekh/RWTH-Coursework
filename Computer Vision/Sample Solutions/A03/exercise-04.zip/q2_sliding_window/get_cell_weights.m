function [cell_x, cell_y, weight] = get_cell_weights(image_height, image_width, cellsize, x, y)
     	
	cell_x = zeros(4,1);
	cell_y = zeros(4,1);
	weight = zeros(4,1);
	n_cells = 0;

	n_cells_x = floor(image_width/cellsize);
	n_cells_y = floor(image_height/cellsize);

	% border behavior
	lower_x = (x <= cellsize/2);
	upper_x = (x > (n_cells_x - 0.5) * cellsize);
	lower_y = (y <= cellsize/2);
	upper_y = (y > (n_cells_y - 0.5) * cellsize);

	% borders
	if lower_x
		% left border
		if lower_y
			% upper left corner
			n_cells = 1;
			cell_x(n_cells) = 1;
			cell_y(n_cells) = 1;
			weight(n_cells) = 1;
		elseif upper_y
			% lower left corner
			n_cells = 1;
			cell_x(n_cells) = 1;
			cell_y(n_cells) = n_cells_y;
			weight(n_cells) = 1;
		else
			% rest of the left border
			n_cells = 2;

			cell_x(1) = 1;
			cell_y(1) = floor((y - 1)/cellsize + 0.5);
			dy = (2*y-1)/(2*cellsize) - cell_y(1) + 0.5;
			weight(1) = 1 - dy;

			cell_x(2) = 1;
			cell_y(2) = cell_y(1) + 1;
			weight(2) = dy;
		end
	elseif upper_x
		% right border
		if lower_y
			% upper right corner
			n_cells = 1;
			cell_x(n_cells) = n_cells_x;
			cell_y(n_cells) = 1;
			weight(n_cells) = 1;
		elseif upper_y
			% lower right corner
			n_cells = 1;
			cell_x(n_cells) = n_cells_x;
			cell_y(n_cells) = n_cells_y;
			weight(n_cells) = 1;
		else
			% rest of the right border
			n_cells = 2;

			cell_x(1) = n_cells_x;
			cell_y(1) = floor((y - 1)/cellsize + 0.5);
			dy = (2*y-1)/(2*cellsize) - cell_y(1) + 0.5;
			weight(1) = 1 - dy;

			cell_x(2) = n_cells_x;
			cell_y(2) = cell_y(1) + 1;
			weight(2) = dy;
		end
	else
		% may still be on upper or lower border
		if lower_y
			% upper border
			n_cells = 2;

			cell_x(1) = floor((x - 1)/cellsize + 0.5);
			cell_y(1) = 1;
			dx = (2*x-1)/(2*cellsize) - cell_x(1) + 0.5;
			weight(1) = 1 - dx;

			cell_x(2) = cell_x(1) + 1;
			cell_y(2) = 1;
			weight(2) = dx;
		elseif upper_y
			% lower border
			n_cells = 2;

			cell_x(1) = floor((x - 1)/cellsize + 0.5);
			cell_y(1) = n_cells_y;
			dx = (2*x-1)/(2*cellsize) - cell_x(1) + 0.5;
			weight(1) = 1 - dx;

			cell_x(2) = cell_x(1) + 1;
			cell_y(2) = n_cells_y;
			weight(2) = dx;
		else
			% in main field
			% here all four cells are defined
			n_cells = 4;
 			 	
			% left upper
			cell_x(1) = floor((x - 1)/cellsize + 0.5);
			cell_y(1) = floor((y - 1)/cellsize + 0.5);
			dx = (2*x-1)/(2*cellsize) - cell_x(1) + 0.5;
			dy = (2*y-1)/(2*cellsize) - cell_y(1) + 0.5;
			weight(1) = (1 - dx) * (1 - dy);

			% right upper
			cell_x(2) = cell_x(1) + 1;
			cell_y(2) = cell_y(1);
			weight(2) = dx * (1 - dy);

			% left bottom
			cell_x(3) = cell_x(1);
			cell_y(3) = cell_y(1) + 1;
			weight(3) = (1 - dx) * dy;

			% right bottom
			cell_x(4) = cell_x(1) + 1;
			cell_y(4) = cell_y(1) + 1;
			weight(4) = dx * dy;
		end
	end

	cell_x = cell_x(1:n_cells);
	cell_y = cell_y(1:n_cells);
	weight = weight(1:n_cells);

end

function scores = object_hypothesis(svm, hog_img, ny_bins, nx_bins)

	[img_y_bins, img_x_bins, n_bins] = size(hog_img);
	ny_windows = (img_y_bins-ny_bins + 1);
	nx_windows = (img_x_bins-nx_bins + 1);
	n_windows =  nx_windows * ny_windows;
	vector_dimension = ny_bins * nx_bins * n_bins;

	windows = zeros(n_windows, vector_dimension);
	idx = 0;
	for x=1:nx_windows
		for y=1:ny_windows
			idx = idx + 1;
			left   = x;
			right  = x + nx_bins - 1;
			top    = y;
			bottom = y + ny_bins - 1;
	 	   
			windows(idx,:) = reshape(hog_img(top:bottom, left:right,:), 1, vector_dimension);
		end
    end
    
    [labels,scores]=predict(svm,windows);
    scores = scores(:,2);
    scores = reshape(scores, ny_windows, nx_windows );

end

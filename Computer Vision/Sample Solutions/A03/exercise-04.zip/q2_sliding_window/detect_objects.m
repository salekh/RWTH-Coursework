function [y,x, score] = detect_objects(hypotheses, threshold)

	hypotheses(hypotheses <= threshold) = 0;
	[y, x, score] = find(hypotheses);

end

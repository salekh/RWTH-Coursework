function dist = hist_dist_euclidean(h1, h2)

	dist = sqrt(sum( (h1-h2).^2 ));
			 		
end

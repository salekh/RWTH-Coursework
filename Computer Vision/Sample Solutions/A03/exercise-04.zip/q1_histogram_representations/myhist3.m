function h = myhist3(filename, bins)
	% read the image and convert it to double
	img = double(imread(filename));
	srgb = sum(img,3);
	R = img(:,:,1)./srgb;
	G = img(:,:,2)./srgb;

	%quantize the image to "bins" number of values
	R=round(R*(bins-1))+1;
	G=round(G*(bins-1))+1;

	%define a 2D histogram with "bins^2" entries
	h = zeros(bins,bins);

	%execute the loop for each pixel in the image
	for i=1:size(img,1)
		for j=1:size(img,2)
			%increment a histogram bin which corresponds to
			%the value of pixel i,j; h(r,g)
			r = R(i,j);
			g = G(i,j);
			h(r,g) = h(r,g)+1;
		end
	end

	%optional: set the bin corresponding to the background color to zero
	h(1,1) = 0; %black
	h(round((bins-1)/3)+1,round((bins-1)/3)+1) = 0; %gray (1,1,1)

	%normalize the histogram such that its integral (sum) is equal 1
	h = h./sum(sum(h));

	%reshape the histogram to obtain a 1D row vector of size 1 x bins^2
	h=reshape(h,1,bins^2); 
end

function h=myhist(filename, bins)
	%read the image and convert it to grayvalues.
	image = double(rgb2gray(imread(filename)));

	%Compute the histogram
	image_vec = reshape(image, 1, []);
	h = hist(image_vec, bins);

	%normalize the histogram such that its integral (sum) is equal 1
	h = h / sum(h);
end

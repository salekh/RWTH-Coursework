function h = myhist2(filename, bins)
	%read the image and convert it to double.
	img1=double(imread(filename));

	%quantize the image to "bins" number of values
	img1=floor(img1*(bins-1)/255)+1;

	%define a 3D histogram  with "bins^3" entries
	h=zeros(bins,bins,bins);
		  	 
	%execute the loop for each pixel in the image,
	for i=1:size(img1,1)
		for j=1:size(img1,2)
			%increment a histogram bin which corresponds to the value of pixel i,j; h(R,G,B)
			R=img1(i,j,1);
			G=img1(i,j,2);
			B=img1(i,j,3);

			h(R,G,B)=h(R,G,B)+1;
		end
	end

	%set the background color (black) bins to 0
	h(1,1,1) = 0;

	%normalize the histogram such that its integral (sum) is equal 1
	h = h / sum(h(:));

	%reshape the histogram to obtain a 1D row vector of size 1 x bins^3
	h=reshape(h,1,bins^3);
		  	 
end

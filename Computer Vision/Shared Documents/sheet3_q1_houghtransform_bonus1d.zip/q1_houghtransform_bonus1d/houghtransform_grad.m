function houghSpace=houghtransform_grad(imgEdge,nBinsRho,nBinsTheta,img_grad_x,img_grad_y)

	acc     = zeros(nBinsRho,nBinsTheta);   % Accumulator
	D       = norm(size(imgEdge));          % Image diagonal
 	
	%[nBinsRho,nBinsTheta]

	off = ( -3:0.5:3 ) * ( pi / 180 );

	% Hough-Transformation
	for x = 1:size(imgEdge,2)
		for y = 1:size(imgEdge,1)
			if imgEdge(y,x) == 1
				% for an edge pixel, do ...
				for i = 1:length(off)
					theta = atan2( img_grad_y(y,x), img_grad_x(y,x) ); % theta from gradient
					theta = theta + off(i);
					rho = x*cos(theta) + y*sin(theta);                 % theta -> rho

					if theta < -pi/2
						theta = theta + pi;
						rho   = -1 * rho;
					elseif theta >= pi/2
						theta = theta - pi;
						rho   = -1 * rho;
					end

					m = round((nBinsRho-1)*( rho + D )/(2*D))+1;       % rho -> bin index
					n = round((nBinsTheta-1)*( theta + pi/2 )/pi) + 1; % theta -> bin index
					%[m,n]
					acc(m,n) = acc(m,n) + 1;                           % vote!
				end
			end
		end
	end

	houghSpace = acc;
 	 		 
end

function [] = apply()
close all;clc;

a = answers();

disp('Question: 2D Structure Extraction');

% -------------------------------------------------------------------------
disp('----- Question a -----');

gantry = double(rgb2gray(imread('gantrycrane.png')));
[ gantry_x, gantry_y ] = gradient_image ( gantry );

% Apply Canny detector
sigma = 2.0;
theta_low = 0.1;
theta_high = 0.3;
imgEdgeGantry = edge(gantry, 'canny', [theta_low, theta_high], sigma);

% Smoothing Control
smooth1=[1];
smooth2=fspecial('gaussian',5,0.7);

f_reply1 = 1.0;
f_reply2 = 0.2;

% Apply hough transform
nBinsRho = 300;
nBinsTheta = 300;
houghSpace = houghtransform(imgEdgeGantry, nBinsRho, nBinsTheta);
houghSpace = filter2 ( smooth1, houghSpace );
houghSpaceGrad = houghtransform_grad(imgEdgeGantry, nBinsRho, nBinsTheta, gantry_x, gantry_y);
houghSpaceGrad = filter2 ( smooth2, houghSpaceGrad );
D = norm(size(imgEdgeGantry)); % Length of image diagonal
T = -pi/2:(pi/(nBinsTheta - 1)):pi/2;
R = -D:(2*D/(nBinsRho - 1)):D;

figure('Position', [200, 400, 400, 400]);
imagesc(gantry);
colormap(gray);
axis off;
axis equal;
title('input image');

figure('Position', [200, 400, 400, 400]);
imagesc(imgEdgeGantry);
colormap(gray);
axis off;
axis equal;
title('input image (edge pixels)');

figure('Position', [200, 400, 400, 400]);
imagesc(T, R, houghSpace);
colormap(hot);
axis off;
title('Hough space');


figure('Position', [200, 400, 400, 400]);
imagesc(T, R, houghSpaceGrad);
colormap(hot);
axis off;
title('Hough space (with gradient)');

disp('Hit key to continue!');
pause;
% -------------------------------------------------------------------------
disp('----- Question b -----');
circuit = double(imread('circuit.png'));
[ circuit_x, circuit_y ] = gradient_image ( circuit );
imgEdgeCircuit = edge(circuit, 'canny', [theta_low, theta_high], sigma);

houghSpaceGantry1 = houghtransform(imgEdgeGantry, 300, 300);
houghSpaceGantry1 = filter2 ( smooth1, houghSpaceGantry1 );
[vRhoGantry1, vThetaGantry1] = findhoughpeaks(houghSpaceGantry1, f_reply1 * 250);
houghSpaceGantry2 = houghtransform_grad(imgEdgeGantry, 300, 300, gantry_x, gantry_y);
houghSpaceGantry2 = filter2 ( smooth2, houghSpaceGantry2 );
[vRhoGantry2, vThetaGantry2] = findhoughpeaks(houghSpaceGantry2, f_reply2 * 250);

houghSpaceCircuit1 = houghtransform(imgEdgeCircuit, 300, 300);
houghSpaceCircuit1 = filter2 ( smooth1, houghSpaceCircuit1 );
[vRhoCircuit1, vThetaCircuit1] = findhoughpeaks(houghSpaceCircuit1, f_reply1 * 170);
houghSpaceCircuit2 = houghtransform_grad(imgEdgeCircuit, 300, 300, circuit_x, circuit_y);
houghSpaceCircuit2 = filter2 ( smooth2, houghSpaceCircuit2 );
[vRhoCircuit2, vThetaCircuit2] = findhoughpeaks(houghSpaceCircuit2, f_reply2 * 170);

fprintf('gantry.png: %d lines\n', size(vRhoGantry1, 1));
fprintf('circuit.png: %d lines\n', size(vRhoCircuit1, 1));
fprintf('gantry.png: %d lines\n', size(vRhoGantry2, 1));
fprintf('circuit.png: %d lines\n', size(vRhoCircuit2, 1));

figure('Position', [200, 400, 800, 400]);
subplot(2, 2, 1);
show_hough_lines(circuit, vRhoCircuit1, vThetaCircuit1, nBinsRho, nBinsTheta);

subplot(2, 2, 2);
show_hough_lines(circuit, vRhoCircuit2, vThetaCircuit2, nBinsRho, nBinsTheta);

subplot(2, 2, 3);
show_hough_lines(gantry, vRhoGantry1, vThetaGantry1, nBinsRho, nBinsTheta);

subplot(2, 2, 4);
show_hough_lines(gantry, vRhoGantry2, vThetaGantry2, nBinsRho, nBinsTheta);

disp('Are all the lines found?');
disp(a.all_lines);

%disp('Hit key to continue!');
%pause;
%% -------------------------------------------------------------------------
%disp('----- Question c (Bonus) houghcircle -----');
%
%disp(a.houghcircle);
%
%% -------------------------------------------------------------------------
%disp('----- Question d (Bonus) coin classification system -----');
%
%disp(a.classification);

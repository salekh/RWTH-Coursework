function [ img_grad_x, img_grad_y ] = gradient_image ( img )

	s_y = [ -0.25, -0.5, -0.25 ; 0.0, 0.0, 0.0 ; 0.25, 0.5, 0.25 ];
	s_x = s_y';

	img_grad_x = filter2 ( s_x, img );
	img_grad_y = filter2 ( s_y, img );
end



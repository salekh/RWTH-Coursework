function a = answers()
	a.hessian_detector_parameters = 'What do you observe?';
end

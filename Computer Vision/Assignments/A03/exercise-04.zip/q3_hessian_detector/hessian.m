function [px, py] = hessian(img, sigma, thresh)


	% insert your code here

end

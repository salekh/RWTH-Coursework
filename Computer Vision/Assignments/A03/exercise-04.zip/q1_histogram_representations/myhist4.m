function h = myhist4(filename, bins)

	% read the image and convert it to double


	% insert your code here

end

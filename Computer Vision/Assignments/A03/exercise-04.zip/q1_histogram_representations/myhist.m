function h=myhist(filename, bins)

	%read the image and convert it to grayvalues.


	% insert your code here

end

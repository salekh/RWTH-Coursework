function dist = hist_dist_euclidean(h1, h2)


	% insert your code here

end

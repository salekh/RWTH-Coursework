function h = myhist3(filename, bins)

	% read the image and convert it to double


	% insert your code here

end

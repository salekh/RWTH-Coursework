function [px, py] = harris(img, sigma, thresh, norm_sigma)


	% insert your code here

end

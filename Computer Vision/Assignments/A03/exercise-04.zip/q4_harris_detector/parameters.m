function p = parameters()
	p.sigmas = [1.6, 3];
	p.thresholds = [500, 1000, 2000];
	p.scales = [1, 2, 4];
end

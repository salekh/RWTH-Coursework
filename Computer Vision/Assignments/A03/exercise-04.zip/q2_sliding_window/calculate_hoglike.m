function hog = calculate_hoglike(img, cellsize, n_bins, sigma, offset_lr, offset_tb, interpolation)


	% insert your code here

end

function [cell_x, cell_y, weight] = get_cell_weights(image_height, image_width, cellsize, x, y)


	% insert your code here

end

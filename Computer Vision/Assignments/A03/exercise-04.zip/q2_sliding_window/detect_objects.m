function [y,x, score] = detect_objects(hypotheses, threshold)


	% insert your code here

end

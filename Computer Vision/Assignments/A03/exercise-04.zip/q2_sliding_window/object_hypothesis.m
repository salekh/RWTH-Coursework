function scores = object_hypothesis(svm, hog_img, ny_bins, nx_bins)


	% insert your code here

end

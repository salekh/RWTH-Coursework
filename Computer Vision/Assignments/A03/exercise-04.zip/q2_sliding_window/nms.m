function result = nms(score)


	% insert your code here

end

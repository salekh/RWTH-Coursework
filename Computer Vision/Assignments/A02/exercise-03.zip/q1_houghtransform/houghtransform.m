function houghSpace=houghtransform(imgEdge,nBinsRho,nBinsTheta)


	% insert your code here

end

function imgResult = nonmaxsup2d(imgHough)


	% insert your code here

end

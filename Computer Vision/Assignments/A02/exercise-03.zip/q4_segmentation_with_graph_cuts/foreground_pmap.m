function foreground_map = foreground_pmap(img, fg_histogram, bg_histogram)


	% insert your code here

end

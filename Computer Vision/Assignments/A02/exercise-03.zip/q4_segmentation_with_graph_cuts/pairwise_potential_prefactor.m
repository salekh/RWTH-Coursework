function score = pairwise_potential_prefactor(img,x1,y1,x2,y2, pairwise_weight)


	% insert your code here

end

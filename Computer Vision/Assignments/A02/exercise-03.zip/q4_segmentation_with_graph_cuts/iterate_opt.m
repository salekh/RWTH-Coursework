function labeling = iterate_opt(img, foreground_mask, n_bins, unary_weight, pairwise_pot, n_iter)


	% insert your code here

end

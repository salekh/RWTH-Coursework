function histogram = calculate_histogram(img, mask, n_bins)


	% insert your code here

end

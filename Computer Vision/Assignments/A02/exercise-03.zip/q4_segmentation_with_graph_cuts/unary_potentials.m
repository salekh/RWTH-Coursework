function potentials = unary_potentials(probability, unary_weight)


	% insert your code here

end

function pairwise_matrix = pairwise_potential_prefactor_matrix(img, pairwise_weight)


	% insert your code here

end

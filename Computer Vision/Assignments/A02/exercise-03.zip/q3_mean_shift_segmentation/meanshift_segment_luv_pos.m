function seg_img = meanshift_segment_luv_pos(img, r)


	% insert your code here

end

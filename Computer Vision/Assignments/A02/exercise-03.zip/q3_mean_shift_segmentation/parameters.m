function p = parameters()
	p.own_image = 'my_seg_img.png';
end

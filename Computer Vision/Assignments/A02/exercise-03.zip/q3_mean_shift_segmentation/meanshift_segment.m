function seg_img = meanshift_segment(img, r)


	% insert your code here

end

function [labels, peaks] = meanshift_opt(data, r)


	% insert your code here

end

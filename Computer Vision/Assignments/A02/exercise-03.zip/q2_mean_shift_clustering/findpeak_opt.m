function [peak,cpts] = findpeak_opt(data, idx, r) 


	% insert your code here

end

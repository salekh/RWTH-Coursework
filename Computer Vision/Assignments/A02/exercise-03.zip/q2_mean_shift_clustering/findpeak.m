function peak = findpeak(data, idx, r) 


	% insert your code here

end

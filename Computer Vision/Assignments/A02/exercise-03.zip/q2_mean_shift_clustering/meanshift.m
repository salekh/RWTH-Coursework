function [labels, peaks] = meanshift(data, r)


	% insert your code here

end
